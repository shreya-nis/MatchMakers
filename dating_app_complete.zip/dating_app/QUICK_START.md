# 🚀 Quick Start Guide - MatchMakers Dating App

Get up and running in **5 minutes!**

## 1️⃣ Install Dependencies (1 minute)

```bash
cd dating_app
npm install
```

**Expected output:** ✅ "added X packages"

## 2️⃣ Start Development Server (30 seconds)

```bash
npm run dev
```

**You should see:**
```
▲ Next.js 14.0.0
- Local:        http://localhost:3000
- Environments: .env.local
```

## 3️⃣ Open in Browser

Click the link or visit: **http://localhost:3000**

You should see the beautiful landing page! 🎉

## 4️⃣ Test the App (3 minutes)

### Test Sign Up
1. Click **"Sign up"** button
2. Fill in the form:
   - Name: `John Doe`
   - Email: `john@example.com`
   - Phone: `+1 234 567 8900`
   - Password: `Password123`
3. Click **"Sign up"**
4. You'll be redirected to dashboard

### Test Login
1. Go to **http://localhost:3000/login**
2. Use your created credentials
3. Click **"Log in"**

### Test Form Validation
Try entering invalid data to see real-time error messages:
- Empty fields
- Invalid email
- Short password
- Invalid phone

## ✅ Common Issues & Solutions

### Port 3000 Already in Use

**Mac/Linux:**
```bash
lsof -ti:3000 | xargs kill -9
```

**Windows:**
```bash
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

### Module Not Found Errors

```bash
rm -rf node_modules
npm install
npm run dev
```

### Tailwind CSS Not Showing

```bash
rm -rf .next
npm run dev
```

## 📂 Project Structure

```
dating_app/
├── src/app/          # Pages & routes
├── src/components/   # Reusable UI components
├── src/store/        # State management
├── src/lib/          # Utilities & validation
└── src/styles/       # Global styles
```

## 🎯 Key Features to Explore

1. **Landing Page** - `/`
   - Beautiful hero section
   - Feature cards
   - Call-to-action buttons

2. **Sign Up** - `/signup`
   - Full form with validation
   - Real-time error messages
   - Smooth animations

3. **Login** - `/login`
   - Email & password form
   - Remember me option
   - Forgot password link

4. **Dashboard** - `/dashboard`
   - Protected route (requires login)
   - User profile display
   - Quick action buttons

## 🎨 Customization

### Change App Name

1. Open `tailwind.config.js`
2. Find colors section
3. Update primary color (default: `#0066FF`)
4. Update secondary color (default: `#FF1493`)

### Change Text Content

Find any text in:
- `src/app/page.tsx` - Home page
- `src/app/signup/page.tsx` - Sign up page
- `src/app/login/page.tsx` - Login page

Just edit and save - hot reload will update instantly!

### Change Logo/Icon

In `src/app/page.tsx` and other files, replace:
```tsx
<IoHeart className="w-12 h-12 text-white" />
```

With your own icon or image.

## 🔗 Connect to Backend (Optional)

When ready to connect to a real API:

1. Create `src/lib/api.ts`:
```typescript
import axios from 'axios';

export const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
});

export const authApi = {
  signUp: (data) => api.post('/auth/signup', data),
  logIn: (email, password) => api.post('/auth/login', { email, password }),
};
```

2. Update `.env.local`:
```
NEXT_PUBLIC_API_URL=https://your-api.com
```

3. Update `src/store/authStore.ts` to use the API calls

## 📦 Build for Production

When ready to deploy:

```bash
npm run build
npm start
```

Visit **http://localhost:3000**

The production build is much faster and smaller!

## 🚀 Deploy to the Internet

### Option 1: Vercel (Recommended)

```bash
npm install -g vercel
vercel
```

Follow the prompts - your app will be live in minutes!

### Option 2: Netlify

```bash
npm install -g netlify-cli
netlify deploy
```

### Option 3: GitHub + Vercel Integration

1. Push code to GitHub
2. Go to vercel.com
3. Click "Import Project"
4. Select your GitHub repo
5. Click "Deploy"

**That's it!** Your app is live! 🎉

## 📚 Learn More

- [Next.js Docs](https://nextjs.org/docs)
- [Tailwind CSS Docs](https://tailwindcss.com)
- [Framer Motion Examples](https://www.framer.com/motion)
- [Zod Validation](https://zod.dev)

## 🎯 Next Steps

1. ✅ Get app running locally
2. ✅ Test all pages and forms
3. ⬜ Customize branding (colors, text, logo)
4. ⬜ Connect to backend API
5. ⬜ Add more features (messages, profiles, matching)
6. ⬜ Deploy to production

## 💡 Pro Tips

**Hot Reload:** Changes save instantly - no need to restart!

**Browser DevTools:** Open with `F12` - inspect elements, debug

**TypeScript Errors:** Check your IDE for type hints

**Form Validation:** Edit `src/lib/validation.ts` to customize

**Animations:** Edit `src/styles/globals.css` for animation timing

## 🆘 Need Help?

1. Check the **README.md** for detailed documentation
2. Check **DEPLOYMENT.md** for deployment instructions
3. Review code comments in component files
4. Check Next.js official documentation

## 🎉 You're All Set!

Your production-ready dating app is ready to customize and deploy!

Happy coding! 🚀

---

**Remember:**
- Always run `npm install` after pulling new code
- Commit your changes to git regularly
- Test thoroughly before deploying
- Monitor your app after deployment

Good luck! 💕
