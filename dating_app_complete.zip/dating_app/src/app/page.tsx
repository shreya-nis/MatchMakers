'use client';

import React from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { IoHeart, IoArrowForward } from 'react-icons/io5';
import Button from '@/components/Button';
import { useAuthStore } from '@/store/authStore';

export default function HomePage() {
  const { isAuthenticated } = useAuthStore();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] },
    },
  };

  const features = [
    {
      icon: '💕',
      title: 'Smart Matching',
      description: 'AI-powered algorithms to find your perfect match'
    },
    {
      icon: '🔒',
      title: 'Secure & Safe',
      description: 'Your privacy and safety are our top priority'
    },
    {
      icon: '⚡',
      title: 'Lightning Fast',
      description: 'Connect with matches instantly'
    },
    {
      icon: '🌟',
      title: 'Premium Features',
      description: 'Unlock exclusive features for better matches'
    }
  ];

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-white via-gray-50 to-white overflow-hidden">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="fixed top-0 w-full bg-white/80 backdrop-blur-md border-b border-gray-100 z-50"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-br from-blue-500 to-pink-500 rounded-full p-2">
              <IoHeart className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-800">MatchMakers</span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-gray-600 hover:text-gray-900 transition">Features</a>
            <a href="#how-it-works" className="text-gray-600 hover:text-gray-900 transition">How it works</a>
            <a href="#faq" className="text-gray-600 hover:text-gray-900 transition">FAQ</a>
          </nav>

          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <Link href="/dashboard">
                <Button variant="primary" size="sm">Dashboard</Button>
              </Link>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="outline" size="sm">Log in</Button>
                </Link>
                <Link href="/signup">
                  <Button variant="primary" size="sm">Sign up</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </motion.header>

      {/* Hero Section */}
      <motion.section
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="pt-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
      >
        {/* Animated Background Elements */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <motion.div
            animate={{
              y: [0, -20, 0],
            }}
            transition={{ duration: 6, repeat: Infinity }}
            className="absolute top-20 left-10 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20"
          />
          <motion.div
            animate={{
              y: [0, 20, 0],
            }}
            transition={{ duration: 8, repeat: Infinity }}
            className="absolute top-40 right-10 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20"
          />
        </div>

        {/* Main Content */}
        <div className="text-center mb-16">
          <motion.div variants={itemVariants} className="flex justify-center mb-8">
            <div className="relative inline-block">
              <div className="absolute inset-0 blur-2xl bg-gradient-to-r from-blue-500 to-pink-500 opacity-30 rounded-full scale-150"></div>
              <div className="relative bg-gradient-to-br from-blue-500 to-blue-600 rounded-full p-6 shadow-lg-glow">
                <IoHeart className="w-16 h-16 text-white animate-float" />
              </div>
            </div>
          </motion.div>

          <motion.h1 variants={itemVariants} className="text-6xl sm:text-7xl font-display font-bold mb-6 text-gray-900">
            Find Your <span className="text-transparent bg-gradient-to-r from-blue-500 via-pink-500 to-blue-500 bg-clip-text">Perfect Match</span>
          </motion.h1>

          <motion.p variants={itemVariants} className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
            Connect with people who share your interests and values. Love starts here.
          </motion.p>

          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/signup">
              <Button variant="primary" size="lg" className="group">
                Get Started
                <IoArrowForward className="group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Button variant="outline" size="lg">Learn More</Button>
          </motion.div>
        </div>
      </motion.section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <motion.h2 variants={itemVariants} className="text-4xl font-bold text-center mb-16 text-gray-900">
            Why Choose MatchMakers?
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                whileHover={{ y: -10 }}
                className="bg-white rounded-2xl p-8 border border-gray-100 shadow-md hover:shadow-xl transition-all"
              >
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="bg-gradient-to-r from-blue-500 to-pink-500 rounded-3xl p-12 text-center shadow-lg-glow"
        >
          <motion.h2 variants={itemVariants} className="text-4xl font-bold text-white mb-6">
            Ready to Find Love?
          </motion.h2>

          <motion.p variants={itemVariants} className="text-white text-lg mb-8 max-w-2xl mx-auto">
            Join thousands of people who have found meaningful connections
          </motion.p>

          <motion.div variants={itemVariants}>
            <Link href="/signup">
              <Button variant="secondary" size="lg">
                Start Your Journey
              </Button>
            </Link>
          </motion.div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 py-12 px-4 sm:px-6 lg:px-8 mt-20">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-2">
              <IoHeart className="w-6 h-6 text-pink-500" />
              <span className="font-bold text-gray-900">MatchMakers</span>
            </div>
            <p className="text-gray-600 text-sm">© 2024 MatchMakers. All rights reserved.</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-gray-900">Features</a></li>
                <li><a href="#" className="hover:text-gray-900">Pricing</a></li>
                <li><a href="#" className="hover:text-gray-900">Security</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-gray-900">About</a></li>
                <li><a href="#" className="hover:text-gray-900">Blog</a></li>
                <li><a href="#" className="hover:text-gray-900">Careers</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-gray-900">Privacy</a></li>
                <li><a href="#" className="hover:text-gray-900">Terms</a></li>
                <li><a href="#" className="hover:text-gray-900">Cookies</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Connect</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-gray-900">Twitter</a></li>
                <li><a href="#" className="hover:text-gray-900">Instagram</a></li>
                <li><a href="#" className="hover:text-gray-900">Facebook</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
