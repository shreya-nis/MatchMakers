import type { Metadata } from 'next';
import { ToastContainer } from '@/components/ToastContainer';
import '@/styles/globals.css';

export const metadata: Metadata = {
  title: 'MatchMakers - Find Your Perfect Match',
  description: 'A modern dating app to find your perfect match',
  keywords: ['dating', 'matchmaking', 'love', 'relationships'],
  authors: [{ name: 'MatchMakers Team' }],
  viewport: 'width=device-width, initial-scale=1.0',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta charSet="utf-8" />
        <meta name="theme-color" content="#0066FF" />
      </head>
      <body className="antialiased">
        {children}
        <ToastContainer />
      </body>
    </html>
  );
}
