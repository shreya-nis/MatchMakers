'use client';

import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { IoHeart, IoLogOut } from 'react-icons/io5';
import Button from '@/components/Button';
import { useAuthStore } from '@/store/authStore';

export default function DashboardPage() {
  const router = useRouter();
  const { user, isAuthenticated, logOut } = useAuthStore();

  React.useEffect(() => {
    if (!isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, router]);

  const handleLogout = () => {
    logOut();
    router.push('/');
  };

  if (!isAuthenticated || !user) {
    return null;
  }

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-white to-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-br from-blue-500 to-pink-500 rounded-full p-2">
              <IoHeart className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-800">MatchMakers</span>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleLogout}
            icon={<IoLogOut />}
          >
            Log out
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <motion.main
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16"
      >
        <div className="bg-white rounded-3xl shadow-lg p-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Welcome, {user.fullName}! 👋
          </h1>
          <p className="text-gray-600 mb-8">
            You've successfully signed in to MatchMakers
          </p>

          {/* User Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <motion.div
              whileHover={{ y: -5 }}
              className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-6 border border-blue-200"
            >
              <h3 className="font-semibold text-gray-900 mb-2">Profile Information</h3>
              <div className="space-y-3 text-sm text-gray-700">
                <p><strong>Email:</strong> {user.email}</p>
                <p><strong>Phone:</strong> {user.phoneNumber}</p>
                <p><strong>Member Since:</strong> {new Date(user.createdAt || '').toLocaleDateString()}</p>
              </div>
            </motion.div>

            <motion.div
              whileHover={{ y: -5 }}
              className="bg-gradient-to-br from-pink-50 to-pink-100 rounded-2xl p-6 border border-pink-200"
            >
              <h3 className="font-semibold text-gray-900 mb-2">Getting Started</h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li>✓ Profile created successfully</li>
                <li>○ Complete your profile</li>
                <li>○ Upload photos</li>
                <li>○ Start discovering matches</li>
              </ul>
            </motion.div>
          </div>

          {/* Quick Actions */}
          <div className="border-t pt-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Quick Actions</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="primary" fullWidth>Edit Profile</Button>
              <Button variant="primary" fullWidth>Upload Photos</Button>
              <Button variant="primary" fullWidth>Browse Matches</Button>
            </div>
          </div>

          {/* Feature Coming Soon */}
          <div className="mt-12 p-8 bg-gradient-to-r from-blue-500/10 to-pink-500/10 rounded-2xl border border-blue-200/50">
            <h3 className="font-bold text-gray-900 mb-2">🎉 More Features Coming Soon</h3>
            <p className="text-gray-600">
              We're continuously adding new features like video calls, messaging, and advanced matching algorithms. Stay tuned!
            </p>
          </div>
        </div>
      </motion.main>
    </div>
  );
}
