'use client';

import React, { useState, useRef } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { IoHeart } from 'react-icons/io5';
import { motion } from 'framer-motion';
import Input from '@/components/Input';
import Button from '@/components/Button';
import { useAuthStore } from '@/store/authStore';
import { validateForm, logInSchema, LogInFormData } from '@/lib/validation';

export default function LoginPage() {
  const router = useRouter();
  const { logIn, isLoading, error, clearError } = useAuthStore();

  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [touchedFields, setTouchedFields] = useState<Set<string>>(new Set());
  const containerRef = useRef<HTMLDivElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: '',
      }));
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const { name } = e.target;
    setTouchedFields((prev) => new Set([...prev, name]));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    clearError();

    const validation = validateForm(logInSchema, formData);
    
    if (!validation.success) {
      setErrors(validation.errors);
      return;
    }

    try {
      await logIn(formData.email, formData.password);
      router.push('/dashboard');
    } catch (err) {
      // Error is handled by the store
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] },
    },
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-white to-gray-50 flex items-center justify-center px-4 py-8">
      <motion.div
        ref={containerRef}
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="w-full max-w-md"
      >
        {/* Logo Section */}
        <motion.div variants={itemVariants} className="flex justify-center mb-8">
          <div className="relative">
            <div className="absolute inset-0 blur-xl bg-gradient-to-r from-blue-500 to-pink-500 opacity-20 rounded-full"></div>
            <div className="relative bg-gradient-to-br from-blue-500 to-blue-600 rounded-full p-4 shadow-glow">
              <IoHeart className="w-12 h-12 text-white animate-float" />
            </div>
          </div>
        </motion.div>

        {/* Title */}
        <motion.div variants={itemVariants} className="text-center mb-8">
          <h1 className="text-4xl font-display font-bold mb-2 text-gray-800">
            Match<span className="text-transparent bg-gradient-to-r from-blue-500 to-pink-500 bg-clip-text">Makers</span>
          </h1>
          <p className="text-gray-600 text-sm">Welcome back</p>
        </motion.div>

        {/* Form Container */}
        <motion.div
          variants={itemVariants}
          className="bg-white rounded-3xl shadow-xl p-8 border border-gray-100"
        >
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Log In</h2>

          {/* Error Alert */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3"
            >
              <span className="text-red-500 text-xl flex-shrink-0">⚠</span>
              <div>
                <p className="font-semibold text-red-700 text-sm">{error}</p>
              </div>
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email Input */}
            <motion.div variants={itemVariants}>
              <Input
                type="email"
                name="email"
                placeholder="Type in your mail address"
                value={formData.email}
                onChange={handleInputChange}
                onBlur={handleBlur}
                error={touchedFields.has('email') ? errors.email : ''}
                disabled={isLoading}
              />
            </motion.div>

            {/* Password Input */}
            <motion.div variants={itemVariants}>
              <Input
                type="password"
                name="password"
                placeholder="Type in your password"
                value={formData.password}
                onChange={handleInputChange}
                onBlur={handleBlur}
                error={touchedFields.has('password') ? errors.password : ''}
                disabled={isLoading}
              />
            </motion.div>

            {/* Forgot Password */}
            <motion.div variants={itemVariants}>
              <Link 
                href="/forgot-password" 
                className="text-blue-500 text-sm hover:text-blue-600 transition-colors inline-block"
              >
                Forgot password?
              </Link>
            </motion.div>

            {/* Login Button */}
            <motion.div variants={itemVariants} className="pt-4">
              <Button
                type="submit"
                variant="primary"
                size="lg"
                fullWidth
                isLoading={isLoading}
                disabled={isLoading || !formData.email || !formData.password}
              >
                {isLoading ? 'Logging in...' : 'Log in'}
              </Button>
            </motion.div>

            {/* Signup Link */}
            <motion.div variants={itemVariants} className="text-center">
              <p className="text-gray-600 text-sm">
                Don't have an account?{' '}
                <Link href="/signup" className="text-blue-500 font-semibold hover:text-blue-600 transition-colors">
                  Sign up
                </Link>
              </p>
            </motion.div>
          </form>
        </motion.div>

        {/* Footer */}
        <motion.div variants={itemVariants} className="text-center mt-6">
          <p className="text-gray-500 text-xs">
            By logging in, you agree to our Terms & Privacy Policy
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}
