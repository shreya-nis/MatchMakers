import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  id: string;
  email: string;
  fullName: string;
  phoneNumber: string;
  password?: string;
  createdAt?: string;
  avatar?: string;
  bio?: string;
  age?: number;
  location?: string;
}

interface AuthStore {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  
  // Auth methods
  signUp: (userData: Omit<User, 'id'>) => Promise<void>;
  logIn: (email: string, password: string) => Promise<void>;
  logOut: () => void;
  clearError: () => void;
  setUser: (user: User) => void;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      signUp: async (userData) => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise((resolve) => setTimeout(resolve, 1500));

          // Validate email format
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(userData.email)) {
            throw new Error('Invalid email format');
          }

          // Validate password
          if (!userData.password || userData.password.length < 6) {
            throw new Error('Password must be at least 6 characters');
          }

          // Validate phone number
          if (!userData.phoneNumber || userData.phoneNumber.length < 10) {
            throw new Error('Invalid phone number');
          }

          const newUser: User = {
            id: `user_${Date.now()}`,
            ...userData,
            createdAt: new Date().toISOString(),
          };

          // Remove password from stored user
          const { password, ...userWithoutPassword } = newUser;

          set({
            user: userWithoutPassword,
            isAuthenticated: true,
            isLoading: false,
          });
        } catch (error) {
          const message = error instanceof Error ? error.message : 'Sign up failed';
          set({
            error: message,
            isLoading: false,
          });
          throw error;
        }
      },

      logIn: async (email, password) => {
        set({ isLoading: true, error: null });
        try {
          // Simulate API call
          await new Promise((resolve) => setTimeout(resolve, 1200));

          if (!email || !password) {
            throw new Error('Email and password are required');
          }

          // Mock validation (in real app, this would call backend)
          const mockUser: User = {
            id: `user_${Date.now()}`,
            email,
            fullName: 'John Doe',
            phoneNumber: '+1 234 567 8900',
            createdAt: new Date().toISOString(),
          };

          set({
            user: mockUser,
            isAuthenticated: true,
            isLoading: false,
          });
        } catch (error) {
          const message = error instanceof Error ? error.message : 'Login failed';
          set({
            error: message,
            isLoading: false,
          });
          throw error;
        }
      },

      logOut: () => {
        set({
          user: null,
          isAuthenticated: false,
          error: null,
        });
      },

      clearError: () => {
        set({ error: null });
      },

      setUser: (user) => {
        set({ user, isAuthenticated: true });
      },
    }),
    {
      name: 'auth-store',
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
);
