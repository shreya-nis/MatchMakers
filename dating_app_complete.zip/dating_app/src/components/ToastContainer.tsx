import { ReactNode } from 'react';
import { IoCheckmarkCircle, IoCloseCircle, IoInformationCircle } from 'react-icons/io5';

type ToastType = 'success' | 'error' | 'info';

interface Toast {
  id: string;
  type: ToastType;
  message: string;
  duration?: number;
}

const toastStyles = {
  success: 'bg-green-500 text-white',
  error: 'bg-red-500 text-white',
  info: 'bg-blue-500 text-white',
};

const toastIcons = {
  success: <IoCheckmarkCircle className="w-5 h-5" />,
  error: <IoCloseCircle className="w-5 h-5" />,
  info: <IoInformationCircle className="w-5 h-5" />,
};

export const showToast = (message: string, type: ToastType = 'info', duration = 3000) => {
  const toastContainer = document.getElementById('toast-container');
  
  if (!toastContainer) return;

  const toastId = `toast-${Date.now()}`;
  const toastElement = document.createElement('div');
  
  toastElement.className = `
    ${toastStyles[type]}
    rounded-lg p-4 mb-3 flex items-center gap-3
    animate-slide-up shadow-lg max-w-md
    transition-all duration-300
  `;
  
  toastElement.innerHTML = `
    <div class="flex items-center gap-3">
      <span class="flex-shrink-0">${SVGToString(toastIcons[type])}</span>
      <span>${message}</span>
    </div>
  `;

  toastContainer.appendChild(toastElement);

  if (duration > 0) {
    setTimeout(() => {
      toastElement.style.opacity = '0';
      toastElement.style.transform = 'translateY(-20px)';
      setTimeout(() => toastElement.remove(), 300);
    }, duration);
  }
};

const SVGToString = (element: ReactNode): string => {
  if (element instanceof SVGElement) {
    return new XMLSerializer().serializeToString(element);
  }
  return '';
};

export const ToastContainer = () => {
  return (
    <div
      id="toast-container"
      className="fixed bottom-6 right-6 z-50 max-h-screen overflow-y-auto pointer-events-none"
    />
  );
};
