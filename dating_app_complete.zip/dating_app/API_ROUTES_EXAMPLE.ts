/**
 * Example API routes for backend integration
 * These are placeholder routes - implement according to your backend
 */

// src/app/api/auth/signup/route.ts

import { NextRequest, NextResponse } from 'next/server';

interface SignUpRequest {
  fullName: string;
  email: string;
  phoneNumber: string;
  password: string;
}

export async function POST(request: NextRequest) {
  try {
    const body: SignUpRequest = await request.json();

    // Validate input
    if (!body.fullName || !body.email || !body.phoneNumber || !body.password) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // TODO: Call your backend API here
    // const response = await fetch(`${process.env.BACKEND_URL}/auth/signup`, {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(body),
    // });

    // Simulate API response
    const userData = {
      id: `user_${Date.now()}`,
      fullName: body.fullName,
      email: body.email,
      phoneNumber: body.phoneNumber,
      createdAt: new Date().toISOString(),
    };

    return NextResponse.json(userData, { status: 201 });
  } catch (error) {
    console.error('Sign up error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// ---

// src/app/api/auth/login/route.ts

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password } = body;

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    // TODO: Call your backend API
    // const response = await fetch(`${process.env.BACKEND_URL}/auth/login`, {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ email, password }),
    // });

    // Simulate API response
    const userData = {
      id: 'user_123',
      email: email,
      fullName: 'John Doe',
      phoneNumber: '+1 234 567 8900',
      token: 'jwt_token_here',
    };

    return NextResponse.json(userData, { status: 200 });
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// ---

// src/app/api/auth/logout/route.ts

export async function POST(request: NextRequest) {
  try {
    // Clear any server-side sessions if needed
    // TODO: Implement logout logic

    return NextResponse.json(
      { message: 'Logged out successfully' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Logout error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// ---

// src/app/api/users/[id]/route.ts

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;

    // TODO: Call your backend API
    // const response = await fetch(`${process.env.BACKEND_URL}/users/${id}`);

    // Simulate API response
    const userData = {
      id,
      fullName: 'John Doe',
      email: 'john@example.com',
      phoneNumber: '+1 234 567 8900',
      bio: 'Love hiking and photography',
      age: 28,
      location: 'San Francisco, CA',
      avatar: 'https://via.placeholder.com/150',
    };

    return NextResponse.json(userData, { status: 200 });
  } catch (error) {
    console.error('Fetch user error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// ---

// src/app/api/matches/route.ts

export async function GET(request: NextRequest) {
  try {
    // Get user's matches from backend
    // TODO: Call your backend API

    const matches = [
      {
        id: '1',
        name: 'Sarah',
        age: 26,
        location: 'San Francisco, CA',
        avatar: 'https://via.placeholder.com/150',
        bio: 'Love outdoor activities',
        compatibility: 95,
      },
      {
        id: '2',
        name: 'Emma',
        age: 27,
        location: 'San Francisco, CA',
        avatar: 'https://via.placeholder.com/150',
        bio: 'Photography enthusiast',
        compatibility: 88,
      },
    ];

    return NextResponse.json(matches, { status: 200 });
  } catch (error) {
    console.error('Fetch matches error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// ---

/**
 * To use these API routes:
 * 
 * 1. Create the route files in src/app/api/[feature]/[route]/route.ts
 * 2. Replace TODO sections with actual API calls
 * 3. Update auth store to use these routes:
 * 
 *    signUp: async (userData) => {
 *      const response = await fetch('/api/auth/signup', {
 *        method: 'POST',
 *        headers: { 'Content-Type': 'application/json' },
 *        body: JSON.stringify(userData),
 *      });
 *      const data = await response.json();
 *      // Handle response
 *    }
 * 
 * 4. Add error handling for network failures
 * 5. Implement authentication tokens (JWT) for secure routes
 */
